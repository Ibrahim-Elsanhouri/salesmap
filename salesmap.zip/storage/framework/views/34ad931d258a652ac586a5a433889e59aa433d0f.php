<!-- First, extends to the CRUDBooster Layout -->

<?php $__env->startSection('content'); ?>
  <!-- Your html goes here -->
  <div class='panel panel-default'>
    <div class='panel-heading'>Attendance Detail</div>
    <div class='panel-body'>      
        <div class='form-group'>
          <label>Empolyee</label>
          <p><?php echo e($attendance->user->name); ?></p>

        </div>
         <div class='form-group'>
          <label>Longtitute</label>
          <p><?php echo e($attendance->long); ?></p>
          
        </div>
        <div class='form-group'>
            <label>Latitute</label>
            <p><?php echo e($attendance->lat); ?></p>
            
          </div>
          <div class='form-group'>
            <label>Address</label>
            <p><?php echo e($attendance->address); ?></p>
            
          </div>
          <div class='form-group'>
            <label>Time</label>
            <p><?php echo e($attendance->created_at); ?></p>
            
          </div>
          <div class='form-group'>
            <label>Duration</label>
            <p><?php echo e($attendance->created_at->diffForHumans()); ?></p>
            
          </div>
         
          <div class='form-group'>
            <label>Map</label>
            <p><a href="https://www.google.com/maps/@'<?php echo e($attendance->lat); ?>','<?php echo e($attendance->long); ?>'z" target="_blank()" class="btn btn=primary"><i class="fa fa-map-marker"></i>View Map</a></p>

          </div>
        <!-- etc .... -->
        
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crudbooster::admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\salesmap\resources\views/attendance.blade.php ENDPATH**/ ?>