<script>
    var x = document.getElementById("demo");
    function getLocation() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
      } else {
      //  x.innerHTML = "Geolocation is not supported by this browser.";
      console.log('Geolocation is not supported by this browser')
      
      }
    }
    
    function showPosition(position) {
        console.log('Latitude:  ' +position.coords.latitude+ 'Longitude:' + position.coords.longitude); 
    //  x.innerHTML = "Latitude: " + position.coords.latitude +
     // "<br>Longitude: " + position.coords.longitude;
     document.getElementById("add_to_me").innerHTML += 
              '<h3>Longtutide :  '+position.coords.longtude+'   , Latitude :'+position.coords.latitude+' </h3>';
    } 
</script>
<?php $__env->startSection('content'); ?>




<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                    <div class="row">
                        <form>
                            <button onclick="getLocation()">Get Location</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\salesmap\resources\views/home.blade.php ENDPATH**/ ?>